import * as URL from "./lib/URL";
import * as URLSearchParams from "./lib/URLSearchParams";

export { URL, URLSearchParams };
